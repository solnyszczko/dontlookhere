#!/usr/bin/env python

from typing import Dict, List, Optional
import random
from ulid import ULID
import json
import copy
import asyncio
import exceptions
import numpy as np
import pygame

# import redis.asyncio as redis
import datetime
from entity import Actor
import entity_factories
from game_map import GameWorld
from input_handlers import MainGameEventHandler
from actions import BumpAction
from setup_game import new_game

import uvicorn

import socketio

mgr = socketio.AsyncManager()
sio = socketio.AsyncServer(async_mode='asgi',client_manager=mgr)

app = socketio.ASGIApp(sio, static_files={
    '/static': './static',
})
background_task_started = False

###
magic_width = 100
magic_height = 100
my_engine = new_game()
event_handler = MainGameEventHandler(my_engine)
clock = pygame.time.Clock()

def input_handler(data, char_id):
    action = event_handler.ev_keydown(data, char_id)
    event_handler.handle_action(action)


def generate_character(id: str) -> Actor:
    player = copy.deepcopy(entity_factories.player)
    player.update_id(id)
    spawn_x = my_engine.game_map.cool_center[0] + random.randint(1, 2)
    spawn_y = my_engine.game_map.cool_center[1] + random.randint(1, 2)
    player.place(spawn_x, spawn_y, my_engine.game_map)

    return player

####


###############




async def background_task():
    """Example of how to send server generated events to clients."""
    count = 0
    while True:
        await sio.sleep(2)
        count += 1
        print("asyncing")
        my_engine.update_fov()
        await broadcast_unique_state()
        my_engine.get_target()
        my_engine.handle_enemy_turns()
        

async def broadcast_unique_state():
        connections = list(mgr.get_participants("/",room="connected_room"))
        for connection in connections:
            game_id= connection[0]
            await sio.emit("map_update",data=my_engine.unique_render(game_id),to=game_id)

@sio.on('my_event')
async def test_message(sid, message):
    await sio.emit('my_response', {'data': message['data']}, room=sid)


@sio.on('my_broadcast_event')
async def test_broadcast_message(sid, message):
    await sio.emit('my_response', {'data': message['data']})


@sio.on('join')
async def join(sid, message):
    sio.enter_room(sid, message['room'])
    print("ENTERED ROOM")
    print(sid)
    print(type(sid))
    print(sio.get)
    await sio.emit('my_response', {'data': 'Entered room: ' + str(message['room'])},
                   room=sid)


@sio.on('leave')
async def leave(sid, message):
    sio.leave_room(sid, message['room'])
    await sio.emit('my_response', {'data': 'Left room: ' + str(message['room'])},
                   room=sid)


@sio.on('close room')
async def close(sid, message):
    await sio.emit('my_response',
                   {'data': 'Room ' + str(message['room'])+ ' is closing.'},
                   room=message['room'])
    await sio.close_room(message['room'])


@sio.on('my_room_event')
async def send_room_message(sid, message):
    await sio.emit('my_response', {'data': message['data']},
                   room=message['room'])


@sio.on('disconnect request')
async def disconnect_request(sid):
    await sio.disconnect(sid)


@sio.on('connect')
async def test_connect(sid, environ):
    global background_task_started
    if not background_task_started:
        sio.start_background_task(background_task)
        background_task_started = True
    sio.enter_room(sid, "connected_room")
    char = generate_character(sid)
    my_engine.insert_actor(char)
   # print(sid)
 #   print(list(mgr.get_participants("/",room="connected_room")))
    await sio.emit('my_response', {'data': 'Connected', 'count': 0}, room=sid)

@sio.on('input')
async def test_message(sid, data):
    print(data)
    input_handler(data, sid)
    await sio.emit('my_response', data)


@sio.on('disconnect')
def test_disconnect(sid):
    print('Client disconnected')


if __name__ == '__main__':
    uvicorn.run(app, host='127.0.0.1', port=5000)