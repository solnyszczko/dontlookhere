from enum import Enum, auto


class EquipmentType(Enum):
    WEAPON = auto()
    ARMOR = auto()
